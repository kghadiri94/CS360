package com.example.module3kayvonghadiri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private EditText mWeightField;
    private Button mSaveButton;

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mWeightField = findViewById(R.id.weight_field);
        mSaveButton = findViewById(R.id.save_button);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = Fire