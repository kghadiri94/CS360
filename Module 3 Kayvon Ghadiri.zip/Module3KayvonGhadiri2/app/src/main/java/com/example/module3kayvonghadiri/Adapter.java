package com.example.module3kayvonghadiri;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private Context mContext;
    private List<Weight> mWeightList;

    public WeightAdapter(Context context, List<Weight> weightList) {
        mContext = context;
        mWeightList = weightList;
    }

    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.weight_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        Weight weight = mWeightList.get(position);
        holder.bind(weight);
    }

    @Override
    public int getItemCount() {
        return mWeightList.size();
    }

    public class WeightViewHolder extends RecyclerView.ViewHolder {

        private TextView mWeightTextView;
        private TextView mDateTextView;

        public WeightViewHolder(View itemView) {
            super(itemView);
            mWeightTextView = itemView.findViewById(R.id.weight_text_view);
            mDateTextView = itemView.findViewById(R.id.date_text_view);
        }

        public void bind(Weight weight) {
            mWeightTextView.setText(String.valueOf(weight.getWeight()));
            mDateTextView.setText(weight.getDate());
        }
    }
}
