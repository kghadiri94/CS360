package com.example.module3kayvonghadiri;

public class RegisterActivity extends AppCompatActivity {
    private EditText mUsernameField;
    private EditText mPasswordField;
    private EditText mNameField;
    private Button mSignUpButton;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mUsernameField = findViewById(R.id.username_field);
        mPasswordField = findViewById(R.id.password_field);
        mNameField = findViewById(R.id.name_field);
        mSignUpButton = findViewById(R.id.signup_button);

        mAuth = FirebaseAuth.getInstance();

        mSignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = mUsernameField.getText().toString();
                String password = mPasswordField.getText().toString();
                String name = mNameField.getText().toString();

                mAuth.createUserWithEmailAndPassword(username, password)
                        .addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // User creation was successful, save the user's name
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                            .setDisplayName(name)
                                            .build();

                                    user.updateProfile(profileUpdates)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        // User name was saved successfully, start the main activity
                                                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                                                    }
                                                }
                                            });
                                } else {
                                    // User creation was not successful, show an error message
                                    Toast.makeText(RegisterActivity.this, "Registration failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }
}
